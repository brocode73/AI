# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 12:33:21 2022

@author: admin
"""

import pandas as pd
df=pd.read_csv('Emp.csv')
df.drop(df[df.basic<2000].index,inplace=True)
print(df)