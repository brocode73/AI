# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 11:22:54 2022

@author: admin
"""

import numpy as np
import pandas as pd
np_array=np.array([10,20,30,40,50])
print("Numpy Array : ")
print(np_array)
new_series=pd.Series(np_array)
print("Converted Pandas Series : ")
print(new_series)