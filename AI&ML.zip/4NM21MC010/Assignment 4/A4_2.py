# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 22:01:40 2022

@author: admin
"""

import matplotlib.pyplot as plt
with open("test.txt")as f:
    data=f.read()
data=data.split('\n')
X=[row.split(' ')[0]for row in data]
Y=[row.split(' ')[1]for row in data]
plt.plot(X,Y)
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Sample Graph')
plt.show()