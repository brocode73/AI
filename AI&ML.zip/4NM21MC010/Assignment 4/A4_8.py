# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 23:20:23 2022

@author: admin
"""

import pandas as pd
ds1=pd.Series([2,4,6,5,10])
ds2=pd.Series([2,3,5,7,9])
print("Series 1 : ")
print(ds1)
print("Series 2 : ")
print(ds2)
print("Compare the elements of the said series : ")
print("Equals")
print(ds1==ds2)
print("Greater than")
print(ds1>ds2)
print("Less than")
print(ds1<ds2)