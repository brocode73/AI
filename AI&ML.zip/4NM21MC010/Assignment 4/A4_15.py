# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 12:07:46 2022

@author: admin
"""

import pandas as pd
df=pd.read_csv('Emp.csv')
print(df[['empname','basic']])