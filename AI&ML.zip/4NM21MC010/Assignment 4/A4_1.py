# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 21:44:43 2022

@author: admin
"""

import matplotlib.pyplot as plt
X=range(1,50)
Y=[value * 3 for value in X]
print("values of X : ")
print(*range(1,50))
print("Values of Y (thrice of X):")
print(Y)
plt.plot(X,Y)
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Draw a line')
plt.show()