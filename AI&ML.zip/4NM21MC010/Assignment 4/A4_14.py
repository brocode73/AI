# -*- coding: utf-8 -*-
"""
Created on Mon Dec  5 11:36:19 2022

@author: admin
"""

import pandas as pd
data=pd.read_csv('Emp.csv')
print(data.iloc[0:3])
