# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 11:35:16 2022

@author: admin
"""

import pandas as pd
a=[]
print("Enter 15 numbers : ")
for i in range(15):
    a.append(int(input("")))
ser=pd.Series(a)
print(ser.value_counts())
