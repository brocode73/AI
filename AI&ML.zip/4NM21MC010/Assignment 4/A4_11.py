# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 11:25:44 2022

@author: admin
"""

import pandas as pd
a=[]
print("Enter the elements : ")
for i in range(10):
    a.append(int(input("")))
s=pd.Series(a)
print("Original Series : ")
print(s)
print("Mean : ")
print(s.mean())
print("Standard Deviation : ")
print(s.std())