# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 22:36:42 2022

@author: admin
"""

import pandas as pd
ds=pd.Series([2,4,6,8,10])
print("Pandas series and types ")
print(ds)
print(type(ds))
print("Convert Pandas series to Python list ")
print(ds.tolist())
print(type(ds.tolist()))