# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 12:26:40 2022

@author: admin
"""

import pandas as pd
data=pd.read_csv('Emp.csv')
commission=data['basic']*0.02
data['commission']=commission
print(data)
data.to_csv('Emp.csv')