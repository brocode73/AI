# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 15:02:29 2022

@author: NITTE Admin
"""

import matplotlib.pyplot as plt
X1=[10,20,30]
Y1=[20,40,10]
plt.plot(X1,Y1,label="line1")
X2=[10,20,30]
Y2=[40,10,30]
plt.plot(X2,Y2,label="line2")
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Two or more lines on same plotwith suitable legends')
plt.legend()
plt.show()