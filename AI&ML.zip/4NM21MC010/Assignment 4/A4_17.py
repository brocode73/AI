# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 12:16:21 2022

@author: admin
"""

import pandas as pd
data=pd.read_csv('Emp.csv')
print(data[data['basic'].isnull()])