# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 11:15:32 2022

@author: admin
"""

import pandas as pd
a={'empno':101,'ename':'Sowmya','basic':3000}
print(a)
print(pd.Series(a))
