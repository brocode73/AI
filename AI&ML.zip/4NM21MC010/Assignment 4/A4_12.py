# -*- coding: utf-8 -*-
"""
Created on Tue Nov 29 11:30:11 2022

@author: admin
"""

import numpy as np
array=[]
print("Enter the elements : ")
for i in range(10):
    array.append(int(input("")))
r1=np.mean(array)
print("Mean : ",r1)
r2=np.std(array)
print("Standard Deviation : ",r2)