# -*- coding: utf-8 -*-
"""
Created on Wed Nov 23 15:09:55 2022

@author: NITTE Admin
"""

import pandas as pd
A=[]
d=int(input("Enter a number : "))
for i in range(d):
  num=int(input("Enter Value : "))
  ds=pd.Series(num)
  A.append(num)
#for i in range(d):
print(ds)