# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 12:30:30 2022

@author: admin
"""

import pandas as pd
data=pd.read_csv('Emp.csv')
print(data.value_counts(['Department']))