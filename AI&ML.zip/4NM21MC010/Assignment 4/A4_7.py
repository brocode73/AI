# -*- coding: utf-8 -*-
"""
Created on Mon Nov 21 23:13:36 2022

@author: admin
"""

import pandas as pd
ds1=pd.Series([2,4,6,8,10])
ds2=pd.Series([1,3,5,7,9])
ds=ds1+ds2
print("Add Two Series : ")
print(ds)
print("Subtract Two Series : ")
ds=ds1-ds2
print(ds)
print("Multiply Two Series : ")
ds=ds1*ds2
print(ds)
print("Divide Series1 by Series2 : ")
ds=ds1/ds2
print(ds)