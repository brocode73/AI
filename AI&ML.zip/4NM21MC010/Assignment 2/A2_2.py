# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 22:43:06 2022

@author: admin
"""

num=int(input(" Enter a number "))
if(num==0 or num==1):
    print("Factorial = 1")
else:
    fact=1
    num1=1
    while(num1<=num):
        fact=fact*num1
        num1=num1+1
print("Factorial = ",fact)
    
