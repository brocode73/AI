# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:16:04 2022

@author: NITTE Admin
"""

min=99999
max=0
choice='Y'
while(choice=='Y' or choice=='y'):
    num=int(input("Enter a number "))
    if(num>max):
        max=num
    if(num<min):
        min=num
    choice=input("Do you want to continu?(Y/N) ")
print("Maximum number : ",max)
print("Minimume number : ",min)
    