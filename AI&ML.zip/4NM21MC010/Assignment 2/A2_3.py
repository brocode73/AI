# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 23:02:54 2022

@author: admin
"""

num=int(input("Enter a number "))
if(num<0):
    print("Enter positive number")
rev=0
#sum1=0
rem=0
while(num>0):
    rem=num%10
    rev=rev*10+rem
    #sum1=sum1+rem
    num//=10
print("Reverse = ",rev)