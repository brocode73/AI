# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:39:41 2022

@author: NITTE Admin
"""

string="Nitte"
newtext=string[-1]+string[1:-1]+string[0]
print("New String : ",newtext)