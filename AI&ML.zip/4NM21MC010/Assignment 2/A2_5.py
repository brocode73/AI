# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:01:54 2022

@author: NITTE Admin
"""

num=int(input("Enter a number : "))
temp=num
rev=0
while temp>0:
    digit=temp%10
    rev=rev*10+digit
    temp=int(temp/10)
if(num==rev):
    print("Entered number is Palindrome")
else:
    print("Entered number is not Palindrome")
