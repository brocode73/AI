# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:06:14 2022

@author: NITTE Admin
"""

positive=negative=zero=0
choice='Y'
while(choice=='y' or choice=='Y'):
    num=int(input("Enter a number "))
    if(num==0):
        zero=zero+1
    elif(num>0):
        positive=positive+1
    elif(num<0):
        negative=negative+1
    choice=input("Do you want to continue?(Y/N)")
print("Positive numbers : ",positive)
print("Negative numbers : ",negative)
print("Zeros : ",zero)
