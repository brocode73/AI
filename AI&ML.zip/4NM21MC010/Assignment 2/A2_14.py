# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:51:09 2022

@author: NITTE Admin
"""

length=lower=upper=digit=False
password=input("Enter a password : ")
if len(password)>8:
    length=True
for letter in password:
    if letter.islower():
        lower=True
    elif letter.isupper():
        upper=True
    elif letter.isdigit():
        digit=True
if length and lower and upper and digit:
    print("Valid Password")
else:
    print("Invalid Password")
        
    