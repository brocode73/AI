# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 09:30:43 2022

@author: NITTE Admin
"""

num=int(input("Enter a positive integer"))
temp=num
sum1=0
while temp>0:
    digit=temp%10
    sum1=sum1+digit
    temp//=10
print("Sum of digits of ",num," is ",sum1)