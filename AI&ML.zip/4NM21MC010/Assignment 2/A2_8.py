# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:22:29 2022

@author: NITTE Admin
"""

n=int(input("Enter number of terms required : "))
first=third=0
second=1
print(first,second,end=' ')
for i in range(3,n+1):
    third=first+second
    print(third,end=' ')
    first=second
    second=third
