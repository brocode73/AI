# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 22:25:00 2022

@author: admin
"""

num=int(input("Enter a number "))
if(num<0):
    print("Enter positive number")
else:
    sum=0
    while(num>0):
        sum=sum+num
        num=num-1
print("Sum = ",sum)
