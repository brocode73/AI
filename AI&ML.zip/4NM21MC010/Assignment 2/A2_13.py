# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:47:08 2022

@author: NITTE Admin
"""

text=input("Enter a String : ")
space1=text.find(' ')
space2=text.find(' ',space1+1)
new_text=text[0]+'. '+text[space1+1]+'. '+text[space2+1]+'.'
print("New String : ",new_text)