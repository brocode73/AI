# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:44:25 2022

@author: NITTE Admin
"""

text=input("Enter a String : ")
new_text=''
for ch in text:
    new_text=ch+new_text
print("New String : ",new_text)s