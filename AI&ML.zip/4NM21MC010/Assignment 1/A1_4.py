# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 21:51:32 2022

@author: admin
"""

str1="Hello world.Good Morning.How are you all.I love the Mountain. I love python lo"
upper=str1.upper()
lower=str1.lower()
length=len(str1)
start=str1.startswith("Hello")
end=str1.endswith("lo")
find=str1.find("the")
count=str1.count("the")
disp=str1[5:11]
remove=str1[:-1]
replace=str1.replace("the","good")
print(upper)
print(lower)
print("Total length :",length)
print("Starts with the: ",start)
print("Ends with lo: ",end)
print("The is found or not :",find)
print("Count of the : ",count)
print("Character from 5th to 10th position: ",disp)
print("Remove last character : ",remove)
print(replace)