# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 00:06:26 2022

@author: admin
"""

ecode=input("Enter the employee code : ")
ename=input("Enter the employee name : ")
job=input("Enter the job : ")
sal=int(input("Enter the salary : "))
if(len(ecode)!=7):
    print("Invalid code")
grade=ecode[0:1]
empno=ecode[1:4]
dep=ecode[4:len(ecode)]
com=0
if(dep=="PRD"):
    com=sal*0.13
elif(dep=="SLS"):
    com=sal*0.08
elif(dep=="ACC"):
    com=sal*0.05
else:
    print("Invalid")
    
if(grade=="A"):
    com=com+300
elif(grade=="B"):
    com=com+200
elif(grade=="C"):
    com=com+100
print("Employee Code : ",ecode)
print("Employee Number : ",empno)
print("Employee Name : ",ename)
print("Department : ",dep)
print("Grade : ",grade)
print("Commission : ",com)
