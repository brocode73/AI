# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 05:43:19 2022

@author: admin
"""

dict={}
eno=int(input("Enter Eno : "))
ename=input("Enter Name : ")
sal=int(input("Enter Basic Salary : "))
dict["eno"]=eno
dict["ename"]=ename
dict["sal"]=sal
dict["da"]=round(sal*0.05)
dict["hra"]=round(sal*0.07)
dict["net"]=dict["sal"]+dict["da"]+dict["hra"]
print("Eno : ",dict["eno"])
print("Ename : ",dict["ename"])
print("Basic Salary : ",dict["sal"])
print("DA : ",dict["da"])
print("HRA : ",dict["hra"])
print("Net Salary : ",dict["net"])
print(dict.keys())
print(dict.values())