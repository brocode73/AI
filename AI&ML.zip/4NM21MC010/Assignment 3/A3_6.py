# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 06:51:07 2022

@author: admin
"""

a=[]
for i in range(3):
    tmp=[]
    print("Enter 3 Number ")
    for j in range(3):
        tmp.append(int(input("")))
    a.append(tmp)
b=[[25,25,25],[25,25,25],[25,25,25]]
sum=[[0,0,0],[0,0,0],[0,0,0]]
diff=[[0,0,0],[0,0,0],[0,0,0]]
mul=[[0,0,0],[0,0,0],[0,0,0]]
for i in range(len(a)):
    for j in range(len(b[0])):
        for k in range(len(b)):
            sum[i][j]=a[i][k]+b[k][j]
            diff[i][j]=a[i][k]-b[k][j]
            mul[i][j]=a[i][k]*b[k][j]
print("Sum is : ")
for s in sum:
    print(s)
print("Difference is : ")
for d in diff:
    print(d)
print("Multiplication is : ")
for m in mul:
    print(m)