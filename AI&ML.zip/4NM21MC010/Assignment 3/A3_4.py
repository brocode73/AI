# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 06:13:40 2022

@author: admin
"""

dict={}
with open('document.txt','r')as file:
    for line in file:
        for word in line.split():
            if dict.get(word):
                dict[word]=dict[word]+1
            else:
                dict[word]=1
max=0
maxword=None
min=0
minword=None
for key,value in dict.items():
    if value==1:
        min=1
        minword=key
    if value>max:
        max=value
        maxword=key
print("Maximum word : ",maxword,"\n MaxCount : ",max)
print("Minimum word : ",minword,"\n MinCount : ",min)
    