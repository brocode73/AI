# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 05:51:09 2022

@author: admin
"""

n1=int(input("No. of elements in Set1 : "))
l1=[]
l2=[]
for i in range(n1):
    num=int(input("Enter a number : "))
    l1.append(num)
n2=int(input("No. of elements in Set2 : "))
for i in range(n2):
    num=int(input("Enter a number : "))
    l2.append(num)
set1=set(l1)
set2=set(l2)
issubset=set2.issubset(set1)
if issubset:
    print("The 2nd set is the subset of 1st set")
else:
    print("The 2nd set is not a subset of 1st set")
    