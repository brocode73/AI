# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 15:31:16 2022

@author: NITTE Admin
"""

import numpy as np
import numpy.matlib
#x=np.array([2,4,5])
#y=np.array([3,5,7])
#dot=np.dot(x,y)
#print(dot)
a=np.matlib.eye(n=3,M=2,k=0,dtype=int)
print("Matrix a : \n",a)
b=np.matlib.eye(n=2,M=3,k=0,dtype=int)
print("Matrix b : \n",b)
print("\n \n",np.dot(a,b))