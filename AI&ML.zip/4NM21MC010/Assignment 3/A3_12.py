# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 15:50:17 2022

@author: NITTE Admin
"""

import numpy as np
arr=np.array([[1,2,3,4],[5,6,7,8]])
print(arr.shape)