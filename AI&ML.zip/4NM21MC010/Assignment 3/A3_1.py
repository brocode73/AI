# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 05:35:23 2022

@author: admin
"""
lst=[]
s=0
for i in range(10):
    num=int(input("Enter a number : "))
    s+=num
    lst.append(num)
lst.sort()
min=lst[0]
max=lst[len(lst)-1]
print("Sum = ",s," Min = ",min," Max = ",max)
    