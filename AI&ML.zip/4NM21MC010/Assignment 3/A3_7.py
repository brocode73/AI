# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 07:02:30 2022

@author: admin
"""

file1=open("myfile.txt","a")
opt="y"
while(opt=="Y" or opt=="y"):
    word=input("Enter word : ")
    file1.write(word)
    file1.write("\n")
    opt=input("Enter Choice : (y or n) : ")
file1.close()
s=input("Enter the match element : ")
f=False
with open("myfile.txt","r")as file:
    for line in file:
        for word in line.split():
            if s==word:
                f=True
                print("Word Found")
    if not f:
        print("Word not found")