# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 06:31:12 2022

@author: admin
"""

x=[]
for i in range(3):
    tmp=[]
    print("Enter 3 number : ")
    for j in range(3):
        tmp.append(int(input("")))
    x.append(tmp)
result=[[0,0,0],
        [0,0,0],
        [0,0,0]]
for i in range(len(x)):
    for j in range(len(x[0])):
        result[j][i]=x[i][j]
for i in result:
    print(i)