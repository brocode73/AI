# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 15:52:31 2022

@author: NITTE Admin
"""

import numpy as np
x=np.array([[2,4,6],[6,8,10]])
print(type(x))
print(x.shape)
print(x.dtype)