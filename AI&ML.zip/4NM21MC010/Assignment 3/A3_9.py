# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 15:14:00 2022

@author: NITTE Admin
"""

import numpy as np
A=[]
for i in range(3):
    tmp=[]
    print("Enter 3 numbers : ")
    for j in range(2):
        tmp.append(int(input("")))
    A.append(tmp)
B=[]
for i in range(2):
    tmp=[]
    print("Enter 2 numbers : ")
    for j in range(3):
        tmp.append(int(input("")))
    B.append(tmp)
print("\n Var of arr ",np.dot(A,B))