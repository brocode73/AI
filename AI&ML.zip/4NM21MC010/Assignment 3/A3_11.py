# -*- coding: utf-8 -*-
"""
Created on Wed Nov 16 15:45:31 2022

@author: NITTE Admin
"""

import numpy as np
a=np.array([[3,1],[2,2]])
w,v=np.linalg.eig(a)
print(w)
print(v)